#!/usr/bin/env python3
import os, sys, json, subprocess, datetime
from pathlib import Path
from urllib.parse import urlparse

SNAP = ".snap"

HELP = """snap - simple Git for small teams

Usage:
  snap save [message]
  snap fetch <url> [--force]
  snap upload [branch] [--force]
"""

# ── tiny wrappers ──
def git(*a, check=True): return subprocess.run(["git", *a], text=True, capture_output=True, check=check)

def out(p, s): print(f"  {p}  {s}")
ok   = lambda s: out("✓", s)
info = lambda s: out("→", s)
warn = lambda s: out("!", s)
die  = lambda s: (out("✗", s), sys.exit(1))

# ── repo helpers ──
is_repo   = lambda: os.path.isdir(".git")
dirty     = lambda: bool(git("status","--porcelain").stdout.strip())
conflicts = lambda: git("diff","--name-only","--diff-filter=U").stdout.split()
cfg_read  = lambda: json.loads(Path(SNAP).read_text()) if Path(SNAP).exists() else {}
cfg_write = lambda d: Path(SNAP).write_text(json.dumps(d, indent=2))

# auto commit if there are changes
def autosave(msg):
    if dirty():
        author = cfg_read()['author'] or "Snap Local Client <snap@local.dev>"
        git("add","."); git("commit","-m",msg,f'--author="' + author + '"')
        ok("Auto-saved workspace.")

# ── commands ──

# save = git add + commit
def save(a):
    if not is_repo(): die("Run 'snap fetch <url>' first.")
    if not dirty(): return info("Nothing to save — workspace is clean.")
    timestmp = datetime.datetime.now().strftime("%y%m%d-%H%M%S")
    m = " ".join(a) or f"snap: Save {timestmp}" # 251226-170536
    author = cfg_read()['author'] or "Snap Local Client <snap@local.dev>"
    git("add","."); git("reset", ".snap"); git("commit","-m",m,f'--author="' + author + '"')
    ok(f'Saved: "{m}"')

# fetch = setup repo + pull changes
def fetch(a):
    force = "--force" in a
    url   = next((x for x in a if not x.startswith("-")), None)
    cfg   = cfg_read()

    # resolve origin (arg > saved > fail)
    origin = url or cfg.get("origin_url") or die("snap fetch <url>")
    u = urlparse(origin.strip())
    if not (u.scheme and u.netloc): origin = str(Path(origin).resolve(False)) # local path fallback

    # init repo if missing
    if not is_repo():
        git("init","-b","main")
        cfg['author'] = "Snap Local Client <snap@local.dev>"
        ok("Initialised new repo (branch: main).")

    # store config
    cfg.update({"origin_url": origin})
    cfg.setdefault("default_branch","main")
    cfg_write(cfg)

    # ensure remote exists
    rem = git("remote").stdout.split()
    git("remote","add" if "origin" not in rem else "set-url","origin",origin)

    autosave("snap: Auto Save before Fetch")
    info(f"Fetching from {origin} …")
    git("fetch","origin")

    b = cfg["default_branch"]

    # force = overwrite everything
    if force:
        git("reset","--hard",f"origin/{b}")
        git("clean","-fd")
        return ok("Force-replaced workspace with origin.")

    # nothing to merge if remote empty
    if f"origin/{b}" not in git("branch","-r",check=False).stdout:
        return ok("Remote empty — start working and run 'snap upload'.")

    # merge normally
    try:
        git("merge",f"origin/{b}","--allow-unrelated-histories")
        ok("Workspace updated.")
    except subprocess.CalledProcessError:
        c = conflicts()
        if not c: die("Merge failed. Check 'git status'.")
        warn("Conflicts detected:")
        for f in c: print(f"     • {f}")
        print(); info("Resolve then run: snap save")

# upload = push with safety checks
def upload(a):
    if not is_repo(): die("Run 'snap fetch <url>' first.")

    force = "--force" in a
    b = next((x for x in a if not x.startswith("-")), "main")
    cfg = cfg_read()
    origin = cfg.get("origin_url") or die("Run 'snap fetch <url>' first.")

    # ensure remote exists
    if "origin" not in git("remote").stdout.split():
        git("remote","add","origin",origin)

    # force push = skip checks
    if force:
        autosave("snap upload: autosave-save")
        git("push","--force","origin",f"HEAD:refs/heads/{b}")
        return ok(f"Force-uploaded to '{b}'.")

    # block if conflicts exist
    if (c := conflicts()):
        warn("Resolve conflicts before uploading:")
        for f in c: print(f"     • {f}")
        return info("Run 'snap save' then retry.")

    # check if behind remote
    git("fetch","origin",check=False)
    try:
        behind = int(git("rev-list","--count",f"HEAD..origin/{b}",check=False).stdout or "0")
    except: behind = 0
    if behind:
        die(f"You are {behind} save(s) behind origin. Run 'snap fetch'.")

    # safe push
    autosave("snap: Auto Save before Upload")
    git 
    git("push","--force","origin",f"HEAD:refs/heads/{b}")
    ok(f"Uploaded to '{b}'.")

# ── entry ──
CMDS = {"save": save, "fetch": fetch, "upload": upload}

def main():
    a = sys.argv[1:]
    if not a or a[0] in ("-h","--help","help"):
        return print(HELP)
    if a[0] not in CMDS:
        die(f"Unknown command '{a[0]}'")

    try:
        CMDS[a[0]](a[1:])
    except subprocess.CalledProcessError as e:
        die(f"Git error: {e.stdout or e.stderr or e}")

if __name__ == "__main__":
    main()